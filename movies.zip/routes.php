<?php
$router->get('/', '/controllers/home.php');
$router->get('/contact', '/controllers/contact.php');
