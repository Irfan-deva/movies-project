<div class="footer">
  i'm a footer
</div>
</body>

</html>