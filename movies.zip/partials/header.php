<?php
echo rootPath('assets/style.css'); ?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="http://127.0.0.1/MOVIESPROJ/assets/style.css">
</head>

<body>
  <div class="header">
    <div class="logo">
      <h1>MV</h1>
    </div>
    <div class="nav">
      <ul>
        <li>Home</li>
        <li>Disclaimer</li>
        <li>Privacy Policy</li>
        <li>Contact Us</li>
      </ul>
    </div>
  </div>