<?php
echo 'i am contact and I am from views';
echo "<br>";
echo $data;
