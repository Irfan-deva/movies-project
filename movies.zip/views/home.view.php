<?php
loadPartial('header');
loadPartial('footer');
