<?php
$data = 'hello world';
loadView('contact', $data);
