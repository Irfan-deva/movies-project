<?php
const HOST = "localhost";
const DB = "movieverse_db";
const USER = "root";
const PWD = "";
